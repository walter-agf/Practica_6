#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Sun May  3 13:47:45 2020

@author: gualteros
"""
h = "Quiero Volver atras"
print (
       h,
       "cuando era feliz"
       )
s = h.split("a")
print (s)